==============================================================================
                          HOOKLOADER (v2.0)
       SetWindowsHookEx DLL Injector with Modern Web Control UI
==============================================================================

[ OVERVIEW ]
Hookloader is a stealth DLL injector designed to load dynamic link libraries 
into target process windows (e.g. Sandbox / Controlled Environment window) using 
Windows message hooking (SetWindowsHookExW - WH_GETMESSAGE). 

It features an embedded, modern dark-themed Web Interface that automatically 
opens in your default browser on startup for seamless, easy DLL selection, 
auto-standby injection waiting, and automatic sandbox restart on unhook.

------------------------------------------------------------------------------
[ PACKAGE CONTENTS ]
------------------------------------------------------------------------------
hookloader/
  |-- hookloader.exe      -> Main Hookloader server & injector application
  |-- hookloader_val.exe  -> Main Hookloader application (alias)
  |-- README.txt          -> Detailed setup and operational instructions
  |-- INSTRUCTIONS.txt    -> Quick-start guide
  \-- src/                -> Complete source code & Visual Studio project
        |-- hookloader.sln
        |-- hookloader/   -> C++ core injector source code
        \-- web_ui/       -> Modern Web GUI front-end source files

------------------------------------------------------------------------------
[ HOW TO RUN & USE ]
------------------------------------------------------------------------------
STEP 1: Run "hookloader.exe" (or "hookloader_val.exe") as Administrator:
        - Right-click executable -> Select "Run as administrator".

STEP 2: The console starts the control server and opens the Web UI at:
        http://127.0.0.1:8080

STEP 3: Upload Payload (Anytime):
        - Click the file upload box or drag and drop your payload DLL.
        - Click the "Inject Payload" button.

STEP 4: Auto-Standby Mode (Pre-Injection Support):
        - You can click "Inject Payload" BEFORE or AFTER launching the target!
        - If the sandbox is not running yet, Hookloader enters Standby Mode 
          and automatically waits for the sandbox/controlled environment target window to open.
        - As soon as the sandbox opens, the hook is committed instantly!

STEP 5: Unhook & Clean Restart:
        - Click "Clear / Unhook" in the Web UI.
        - Hookloader detaches the Windows hook, terminates the sandbox process, 
          and automatically restarts the sandbox cleanly so no lingering DLL 
          remains in memory.

------------------------------------------------------------------------------
[ TROUBLESHOOTING & FAQ ]
------------------------------------------------------------------------------
Q: The browser didn't open automatically.
A: Manually navigate to http://127.0.0.1:8080 in Chrome, Edge, or Firefox.

Q: Standby mode is active ("Waiting for target window...").
A: Launch your sandbox/controlled environment. Hookloader will detect the window 
   and complete the injection automatically.

Q: Error: "Bind failed on port 8080"
A: Another application is already using port 8080. Close that application 
   or release port 8080 and restart hookloader.exe.

Q: Antivirus triggered a detection.
A: Windows Hooking (SetWindowsHookExW) and memory manipulation are frequently 
   flagged as heuristic false-positives by antivirus software. Add an exclusion 
   if necessary.

------------------------------------------------------------------------------
[ COMPILING FROM SOURCE ]
------------------------------------------------------------------------------
Requirements:
- Visual Studio 2022 / 2026 with Desktop C++ Workload (MSVC toolset)
- Windows 10 / 11 SDK

Steps:
1. Open "src/hookloader.sln" in Visual Studio.
2. Select "Release" and "x64" configuration.
3. Build the solution (Ctrl + Shift + B).
==============================================================================
